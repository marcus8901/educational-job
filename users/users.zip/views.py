from django.shortcuts import render, redirect
from .models import Reg, Transfer
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required



from .forms import ProfileForm

# Create your views here.

def logoutUser(request):
    logout(request)

    return redirect ("home")
    # return render(request, "webpage/home.html")

@login_required(login_url='home')
def dashboard(request):

    transfer = Transfer.objects.filter(user=request.user)
    context = {
        'transfer':transfer
    }
   
    return render(request, "users/dashboard.html",context)


@login_required(login_url='home')
def accountsummary(request):
   
    return render (request, "users/accountsummary.html")

@login_required(login_url='home')
def accountdetails(request):
   
    return render (request, "users/accountdetails.html")

@login_required(login_url='home')
def creditcards(request):
    return render (request, "users/creditcards.html")

@login_required(login_url='home')
def contactus(request):
    return render (request, "users/contactus.html")

@login_required(login_url='home')
def billpaycenter(request):

    return render(request, "users/billpaycenter.html")

@login_required(login_url='home')
def deletepaytoaccount(request):

    return render (request, "users/deletepaytoaccount.html")

@login_required(login_url='home')
def paynow(request):

    return render (request, "users/paynow.html")

@login_required(login_url='home')
def paynowc(request):

    return render (request, "users/paynowc.html")

@login_required(login_url='home')
def searchpaytolist(request):

    return render (request, "users/searchpaytolist.html")

@login_required(login_url='home')
def beneficiary(request):

    return render (request, "users/beneficiary.html")

@login_required(login_url='home')
def addbeneficiery(request):

    return render (request, "users/add-beneficiery.html")

def profile(request):
    
    reg = request.user.reg
    form = ProfileForm(instance=reg)

    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES, instance=reg)
        if form.is_valid():
            form.save()

    context ={'form':form}
    return render (request, "users/profile.html", context)

def changepin(request):

    return render(request, "users/pin.html")

def changepassword(request):

    
    return render(request, "users/changepassword.html")

def transfer(request):

    if Transfer.objects.filter(user=request.user).exists():
        messages.error(request, "This account is RESTRICTED and can't perform this operation")
        return redirect('dashboard')
        
    if request.method == 'POST':
        amount = request.POST.get('amount')
        description = request.POST.get('transaction_description')
        # icon = request.POST.get('icon')
        pin = request.POST.get('security_pin')
        print(pin)
        # print
        # date = request.POST.get('date')

        if not Transfer.objects.filter(user=request.user).exists():
            get_pin = Reg.objects.get(user=request.user)
            if str(get_pin.account_pin) == str(pin):
                abc = Reg.objects.get(user=request.user).account_balance
                Reg.objects.filter(user=request.user).update(account_balance=int(abc)-int(amount))
                Transfer.objects.create(counter=1,description=description,amount=amount,user=request.user)
                return redirect('successful')

        else:
            messages.warning(request, "This account is RESTRICTED and cannot perfom this operation!")
            return redirect('dashboard')
    
    return render(request, "users/transfer.html")

def enterpin(request):

    return render(request, "users/enterpin.html")


def confirm_transfer(request):


    return render (request, "users/confirm_transfer.html")

def successful(request):

    return render (request, "users/successful.html")
    