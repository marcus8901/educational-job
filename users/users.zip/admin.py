from django.contrib import admin
from .models import Reg, Transfer
# Register your models here.

admin.site.register(Reg)
admin.site.register(Transfer)
